# -*- coding: utf-8 -*-
#------------------------------------------------------------
# XBMC Add-on for Disney Junior
# Version 1.0.0
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------
# Changelog:
# 1.0.0
# - First release
#---------------------------------------------------------------------------

import os
import sys
import urlparse

import plugintools

# YouTube channel shown
YOUTUBE_CHANNEL_ID = plugintools.get_setting("youtube_channel_id")

# Localized strings
T_OFFICIAL_WEBSITE=30002
T_YOUTUBE_CHANNEL=30003
T_SEARCH=30004
T_PREFERENCES=30005

# Entry point
def run():
    plugintools.log("disneyjunior.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("disneyjunior.main_list "+repr(params))

    plugintools.add_item( 
        action="disneyweb", 
        title=plugintools.get_localized_string(T_OFFICIAL_WEBSITE) ,
        url="http://www.disney.es/disney-junior/contenido/video.jsp" ,
        folder=True )
    
    plugintools.add_item(
        action="youtube_playlists",
        title=plugintools.get_localized_string(T_YOUTUBE_CHANNEL),
        url="http://gdata.youtube.com/feeds/api/users/"+YOUTUBE_CHANNEL_ID+"/playlists?v=2&start-index=1&max-results=30",
        folder=True )
    
    plugintools.add_item( action="search",
        title=plugintools.get_localized_string(T_SEARCH) )
    
    plugintools.add_item( action="preferences",
        title=plugintools.get_localized_string(T_PREFERENCES),
        folder = False )

# Show all videos from the official website
def disneyweb(params):
    plugintools.log("disneyjunior.disneyweb "+repr(params))

    # Fetch video list from YouTube feed
    data = plugintools.read( params.get("url") )
    data = plugintools.find_single_match( data , '<div id="video_main_promos_inner">(.*?)<div id="content_index_navigation">')
    
    # Extract items from feed
    '''
    <div class="promo" style="background-image: url(/cms_res/disney-junior/images/promo_support/promo_holders/video.png);">
        <a href="/disney-junior/contenido/video/canta_con_dj_arcoiris.jsp " class="promoLinkTracking"><img src="/cms_res/disney-junior/images/video/canta_dj_arco_iris_164x104.jpg" class="promo_image" alt=""/></a>
        <div class="promo_title_3row"><p>Canta con DJ: La canción del arco iris</p></div>
        <a class="playlist_button_large"  href="" ref="canta_con_dj_arcoiris"><img src="/cms_res/disney-junior/images/promo_support/playlist_add_icon.png" alt="" /></a>
    </div>
    '''
    pattern  = '<div class="promo"[^<]+'
    pattern += '<a href="([^"]+)"[^<]+'
    pattern += '<img src="([^"]+)"[^<]+'
    pattern += '</a[^<]+'
    pattern += '<div[^<]+'
    pattern += '<p>([^<]+)</p>'
    matches = plugintools.find_multiple_matches(data,pattern)
    
    for scrapedurl, scrapedthumbnail, scrapedtitle in matches:
        # Not the better way to parse XML, but clean and easy
        title = scrapedtitle
        thumbnail = urlparse.urljoin( params.get("url") , scrapedthumbnail )
        url = urlparse.urljoin( params.get("url") , scrapedurl.strip() )
        plot = ""

        # Appends a new item to the xbmc item list
        plugintools.add_item( action="disneyweb_play" , title=title , plot=plot , url=url ,thumbnail=thumbnail , isPlayable=True, folder=False )

# Play one video from the official website
def disneyweb_play(params):
    plugintools.log("disneyjunior.disneyweb_play "+repr(params))

    # Fetch page
    data = plugintools.read( params.get("url") )

    url_start = plugintools.find_single_match( data , "config.rtmpeServer \= '([^']+)'")
    plugintools.log("disneyjunior.disneyweb_play url_start="+url_start)

    url_end = plugintools.find_single_match( data , "config.firstVideoSource \= '([^']+)'")
    plugintools.log("disneyjunior.disneyweb_play url_end="+url_end)
    
    url = url_start + url_end
    plugintools.log("disneyjunior.disneyweb_play url="+url)

    plugintools.play_resolved_url( url )

# Show all YouTube playlists for the selected channel
def youtube_playlists(params):
    plugintools.log("disneyjunior.youtube_playlists "+repr(params))

    # Fetch video list from YouTube feed
    data = plugintools.read( params.get("url") )
    plugintools.log("data="+data)
    
    # Extract items from feed
    pattern = ""
    matches = plugintools.find_multiple_matches(data,"<entry(.*?)</entry>")
    
    for entry in matches:
        plugintools.log("entry="+entry)
        
        # Not the better way to parse XML, but clean and easy
        title = plugintools.find_single_match(entry,"<titl[^>]+>([^<]+)</title>")
        plot = plugintools.find_single_match(entry,"<media\:descriptio[^>]+>([^<]+)</media\:description>")
        thumbnail = plugintools.find_single_match(entry,"<media\:thumbnail url='([^']+)'")
        url = plugintools.find_single_match(entry,"<content type\='application/atom\+xml\;type\=feed' src='([^']+)'/>")

        # Appends a new item to the xbmc item list
        plugintools.add_item( action="youtube_videos" , title=title , plot=plot , url=url , thumbnail=thumbnail , folder=True )

# Show all YouTube videos for the selected playlist
def youtube_videos(params):
    plugintools.log("disneyjunior.youtube_videos "+repr(params))

    # Fetch video list from YouTube feed
    data = plugintools.read( params.get("url") )
    plugintools.log("data="+data)
    
    # Extract items from feed
    pattern = ""
    matches = plugintools.find_multiple_matches(data,"<entry(.*?)</entry>")
    
    for entry in matches:
        plugintools.log("entry="+entry)
        
        # Not the better way to parse XML, but clean and easy
        title = plugintools.find_single_match(entry,"<titl[^>]+>([^<]+)</title>")
        title = title.replace("Disney Junior España | ","")
        plot = plugintools.find_single_match(entry,"<summa[^>]+>([^<]+)</summa")
        thumbnail = plugintools.find_single_match(entry,"<media\:thumbnail url='([^']+)'")
        video_id = plugintools.find_single_match(entry,"http\://www.youtube.com/watch\?v\=([0-9A-Za-z_-]{11})")
        url = "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+video_id

        # Appends a new item to the xbmc item list
        plugintools.add_item( action="play" , title=title , plot=plot , url=url , thumbnail=thumbnail , isPlayable=True, folder=False )

# Play selected vieo
def play(params):
    plugintools.play_resolved_url( params.get("url") )

# Open preferences dialog
def preferences(params):
    plugintools.log("disneyjunior.configuracion "+repr(params))

    plugintools.open_settings_dialog()

# Open a popup dialog for input search terms, then call the result function
def search(params):
    plugintools.log("disneyjunior.search "+repr(params))

    last_search = plugintools.get_setting("last_search")
    texto = plugintools.keyboard_input(last_search)
    plugintools.set_setting("last_search",texto)

    params["texto"]=texto
    
    youtube_search(params)

# Show first 50 videos from YouTube that matches a search string
def youtube_search(params):
    plugintools.log("disneyjunior.search "+repr(params))

    # Fetch video list from YouTube feed
    data = plugintools.read( "https://gdata.youtube.com/feeds/api/videos?q="+params.get("texto").replace(" ","+")+"&orderby=published&start-index=1&max-results=50&v=2&lr="+plugintools.get_setting("youtube_language") )
    plugintools.log("data="+data)
    
    # Extract items from feed
    pattern = ""
    matches = plugintools.find_multiple_matches(data,"<entry(.*?)</entry>")
    
    for entry in matches:
        plugintools.log("entry="+entry)
        
        # Not the better way to parse XML, but clean and easy
        title = plugintools.find_single_match(entry,"<titl[^>]+>([^<]+)</title>")
        plot = plugintools.find_single_match(entry,"<summa[^>]+>([^<]+)</summa")
        thumbnail = plugintools.find_single_match(entry,"<media\:thumbnail url='([^']+)'")
        video_id = plugintools.find_single_match(entry,"http\://www.youtube.com/watch\?v\=([0-9A-Za-z_-]{11})")
        if video_id=="":
            video_id = plugintools.find_single_match(entry,"https\://www.youtube.com/watch\?v\=([0-9A-Za-z_-]{11})")
        url = "plugin://plugin.video.youtube/?path=/root/video&action=play_video&videoid="+video_id

        # Appends a new item to the xbmc item list
        plugintools.add_item( action="play" , title=title , plot=plot , url=url , thumbnail=thumbnail , isPlayable=True, folder=False )

run()