# -*- coding: utf-8 -*-

from Common import logger
from Common import tools
import re
import xbmcplugin
import urlparse
import json


args = urlparse.parse_qs(sys.argv[2][1:])
#recupera el argumento action
action = args.get('action', None)
domain = "http://enraged.es/kodiaddon"
addon_handle = int(sys.argv[1])

if action is None:

    #Aquí sólo entra la primera vez para que el usuario pueda escoger categorías (fotos o videos)

    html = tools.getUrl(domain)
    
    pattern = '<figure>(.*?)</figure>'

    matches = tools.findall(pattern,html, re.DOTALL)

    for match in matches:
        
        pattern = 'ng-href="#/category/(.*?)">'
        category = tools.findall(pattern, match , re.DOTALL)[0]

        if category == 'photo':
            url = tools.build_url({'action':'categorias','url_':'http://enraged.es/kodiaddon/php/getCategorias.php?contentType=photo'})
        else:
            url = tools.build_url({'action': 'categorias', 'url_' : 'https://cinecalidad.is'})
      
        pattern = 'alt="(.*)"'
        label = tools.findall(pattern,match, re.DOTALL)[0]

        pattern = 'src="(.*?)"'
        thumbnail = tools.findall(pattern,match, re.DOTALL)[0]

        thumbnail = thumbnail.replace("./", "/")
        thumbnail = domain + thumbnail

        tools.addItemMenu(label = label,thumbnail= thumbnail, url= url,IsPlayable = 'false', isFolder= True)

    xbmcplugin.endOfDirectory(addon_handle) 

else:
   
    if action[0] == 'categorias':

        url_ = args.get('url_',None)[0]

        response = tools.getUrl(url_)

        data = json.loads(response)
       
        for item in data:
            category = item['category']
            description =  item['description']
            thumbnail = domain + "/" + item['thumbnail']

            url = tools.build_url({'action':'subcategorias','url_':'http://enraged.es/kodiaddon/php/getContenido.php?category=' + category})

            tools.addItemMenu(label = description,thumbnail= thumbnail, url= url,IsPlayable = 'false', isFolder= True)
     
        xbmcplugin.endOfDirectory(addon_handle) 

    if action[0] == 'subcategorias':

        url_ = args.get('url_',None)[0]

        logger.debug("paso por aqui: " + url_)	
        response = tools.getUrl(url_)

        data = json.loads(response)

        for item in data:

            contentPath = item['contentPath']
            description = item['contentPath']
            thumbnail = domain + "/" + contentPath
            url = domain + "/" + contentPath

            tools.addItemMenu(label = description,thumbnail= thumbnail, url= url,IsPlayable = 'true', isFolder= False)

        xbmcplugin.endOfDirectory(addon_handle)




